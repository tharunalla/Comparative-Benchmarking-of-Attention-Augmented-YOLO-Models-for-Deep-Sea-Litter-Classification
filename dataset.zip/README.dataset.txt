# ExtractDetails > 2025-04-13 4:52pm
https://universe.roboflow.com/dlcv-lsqor/extractdetails

Provided by a Roboflow user
License: Public Domain

